from re import UNICODE
from django import forms
from django.shortcuts import render, get_object_or_404
from .models import OrderItem
from .forms import OrderCreateForm
from cart.cart import Cart
from .tasks import order_created
import smtplib, ssl
from simple_colors import *


def order_create(request):
    cart = Cart(request)
    if request.method == "POST":
        form = OrderCreateForm(request.POST)
        if form.is_valid():

            firstname = request.POST.get("first_name")
            lastname = request.POST.get("last_name")
            emailvalue = request.POST.get("email")

            order = form.save()
            for item in cart:
                OrderItem.objects.create(
                    order=order,
                    product=item["product"],
                    price=item["price"],
                    quantity=item["quantity"],
                )
            # clear the cart
            # cart.clear()
            # launch asynchronous task
            # order_created.delay(order.id)
            # --------------------------
            k = 1
            cart_content = ""
            for item in cart:
                cart_content = (
                    cart_content + "Наименование = " + str(item["product"]) + "\n"
                )
                cart_content = (
                    cart_content + "Количество = " + str(item["quantity"]) + "\n"
                )
                cart_content = cart_content + "Цена = " + str(item["price"]) + "\n"
                cart_content = cart_content + " \n\n"
            cart_content = cart_content + "Итого = " + str(cart.get_total_price())

            server = smtplib.SMTP_SSL("smtp.mail.ru", 465)
            server.login("runo200", "bPMe3wny38A8sih4xuqL")
            server.sendmail(
                "runo200@mail.ru",
                emailvalue,
                firstname.encode()
                + " \n".encode()
                + lastname.encode()
                + " \n".encode()
                + emailvalue.encode()
                + " \n\n\n".encode()
                + cart_content.encode(),
            )
            server.quit()

            return render(request, "orders/order/created.html", {"order": order})

    else:
        form = OrderCreateForm()
    return render(request, "orders/order/create.html", {"cart": cart, "form": form})
