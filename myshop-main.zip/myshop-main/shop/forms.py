from django.forms import CharField, ModelForm, forms
from .models import Product
from django.core import validators


class ProductForm(ModelForm):
    # slug = CharField(validators=[validators.validate_slug])

    class Meta:
        model = Product
        fields = ['category', 'name',
                  'image', 'price', 'description', ]
