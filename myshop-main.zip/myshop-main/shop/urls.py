from django.urls import path
from django.conf.urls import include, url
from . import views


app_name = 'shop'

urlpatterns = [
    path('index/', views.index, name='index'),
    path('', views.product_list, name='product_list'),
    path('<slug:category_slug>/', views.product_list,
         name='product_list_by_category'),
    path('<int:id>/<slug:slug>/', views.product_detail,
         name='product_detail'),

]
