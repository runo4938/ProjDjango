from django.db import models
from django.urls import reverse
from pytils.translit import slugify
from django.utils.formats import number_format
from decimal import Decimal


class Category(models.Model):
    name = models.CharField(max_length=200, db_index=True)
    slug = models.SlugField(max_length=200,
                            unique=True)

    class Meta:
        ordering = ('name',)
        verbose_name = 'Категория'
        verbose_name_plural = 'категорий'

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('shop:product_list_by_category',
                       args=[self.slug])


class Product(models.Model):
    category = models.ForeignKey(Category,
                                 related_name='products',
                                 on_delete=models.CASCADE)
    name = models.CharField(max_length=200, db_index=True,
                            verbose_name='Наименовние')
    slug = models.SlugField(max_length=200, db_index=True)
    image = models.ImageField(upload_to='products/%Y/%m/%d',
                              blank=True)
    description = models.TextField(blank=True)
    price = models.DecimalField(
        max_digits=10, decimal_places=2, verbose_name='Цена')
    available = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    SizeProduct = models.CharField(max_length=70, verbose_name='Размеры')
    ColorProduct = models.CharField(max_length=170, verbose_name='Цвета')
    sale = models.BooleanField(verbose_name='Распродажа')

    class Meta:
        ordering = ('name',)
        index_together = (('id', 'slug'),)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('shop:product_detail',
                       args=[self.id, self.slug])

    def size_select(self):
        sl = str(self.SizeProduct).split(' ')
        sv = [(i, sl[i]) for i in range(1, len(sl))]
        return sl

    def save(self, *args, **kwargs):
        self.slug = slugify(self.name)
        # Call the real save() method
        super(Product, self).save(*args, **kwargs)


"""
tshirt = Category.objects.create(name='tshirts',slug='tshirt')
notebook = Category.objects.create(name='notebook',slug='notebook')

# Tshirts
Product.objects.create(name='Silk tshirt', category=tshirt, price=100, attributes={
    'colors': ['red', 'black'],
    'sizes': ['S', 'M'],
    'model': 'polo',
    'material': 'silk',
})"""
