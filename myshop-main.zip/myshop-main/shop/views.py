from django.shortcuts import render, get_object_or_404
from .models import Category, Product
from cart.forms import UserForm, CartAddProductForm
from django.http import HttpResponse
from django.views.generic.edit import CreateView
from django.views.generic import ListView
from django import forms
from .forms import ProductForm

ChoiseColor = [(1, 'red'), (2, 'green'), (3, 'braun')]


def index(request):
    if request.method == "POST":
        userform = UserForm(request.POST)
        if userform.is_valid():
            dt = userform.cleaned_data
            name = dt['name']
            age = dt['age']
            color = dt['color']
            return HttpResponse("<h2>Hello, {0} <br>age {1} <br> color {2} </h2>".format(name, age, color))
        else:
            return HttpResponse("Invalid data")
    else:
        userforms = UserForm()
        #userforms.fields['summ'].choices = ChoiseColor
        return render(request, "index.html", {"form": userforms})


def product_list(request, category_slug=None):
    category = None
    categories = Category.objects.all()
    products = Product.objects.filter(available=True)
    if category_slug:  # sdfsdf
        category = get_object_or_404(Category, slug=category_slug)
        products = products.filter(category=category)
    return render(request,
                  'shop/product/list.html',
                  {'category': category,
                   'categories': categories,
                   'products': products,
                   })

# Try add commit


def product_detail(request, id, slug):
    product = get_object_or_404(Product,
                                id=id,
                                slug=slug,
                                available=True,)
    # forms.CHOICE =
    ch = str(product.SizeProduct).split(' ')
    sm = [(i, ch[i]) for i in range(0, len(ch))]
    cart_product_form = CartAddProductForm()
    cart_product_form.fields['sizes'].choices = sm

    cl = str(product.ColorProduct).split(' ')
    col = [(i, cl[i]) for i in range(0, len(cl))]
    cart_product_form.fields['colors'].choices = col
    return render(request,
                  'shop/product/detail.html',
                  {'product': product,
                   'cart_product_form': cart_product_form})


class ProductCreateView(CreateView):
    model = Product
    template_name = "shop/product/create.html"
    form_class = ProductForm
    success_url = '/list/'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["Category"] = Category.objects.all()
        return context
