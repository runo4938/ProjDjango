from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from shop.models import Product
from .cart import Cart
from .forms import CartAddProductForm
from django.forms.fields import IntegerField


@require_POST
def cart_add(request, product_id):

    cart = Cart(request)
    product = get_object_or_404(Product, id=product_id)
    ch = str(product.SizeProduct).split(' ')
    sm = [(i, ch[i]) for i in range(0, len(ch))]
    form = CartAddProductForm(request.POST)
    form.fields['sizes'].choices = sm

    cl = str(product.ColorProduct).split(' ')
    col = [(i, cl[i]) for i in range(0, len(cl))]
    form.fields['colors'].choices = col
    if form.is_valid():
        cd = form.cleaned_data
        x = ch[int(cd['sizes'])]
        c = cl[int(cd['colors'])]
        cart.add(product=product,
                 quantity=cd['quantity'],
                 update_quantity=cd['update'],
                 sizes=x,
                 colors=c)

    return redirect('cart:cart_detail')


def cart_remove(request, product_id):
    cart = Cart(request)

    product = get_object_or_404(Product, id=product_id)
    cart.remove(product)
    return redirect('cart:cart_detail')


def cart_detail(request):
    cart = Cart(request)
    for item in cart:
        item['update_quantity_form'] = CartAddProductForm(
            initial={'quantity': item['quantity'],
                     'update': True,
                     'sizes': item['sizes'],
                     'colors': item['colors'],
                     })
    return render(request, 'cart/detail.html', {'cart': cart})
