from django import forms
from shop.models import Product
from django.shortcuts import render, get_object_or_404
from django.conf.locale import sl
from django.forms.widgets import HiddenInput, RadioSelect
from django.forms.models import ModelChoiceField
from django.http import request


PRODUCT_QUANTITY_CHOICES = [(i, str(i)) for i in range(1, 21)]
FAVORITE_COLORS_CHOICES = (("1", "green"), ("2", "brown"))


class UserForm(forms.Form):
    color = forms.ChoiceField(
        choices=FAVORITE_COLORS_CHOICES, widget=forms.RadioSelect, required=False
    )
    name = forms.CharField()
    age = forms.IntegerField()


class CartAddProductForm(forms.Form):
    quantity = forms.IntegerField()
    update = forms.BooleanField(required=False, initial=False, widget=forms.HiddenInput)
    sizes = forms.ChoiceField(
        choices=[],
        widget=RadioSelect,
        required=True,
    )
    colors = forms.ChoiceField(choices=[], widget=RadioSelect, required=True)

    # def __init__(self, *args, **kwargs):
    #     hide_condition = kwargs.pop('hide_condition', None)
    #     super(CartAddProductForm, self).__init__(*args, **kwargs)
    #     if hide_condition:
    #         self.fields['quantity1'].widget = HiddenInput()
